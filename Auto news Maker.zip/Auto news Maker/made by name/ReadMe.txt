This is made by me coded by me dont resell this because this is free for all iwont ask u for any payment for this exe so yea enjoy

